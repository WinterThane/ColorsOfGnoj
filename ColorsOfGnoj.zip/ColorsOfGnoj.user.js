// ==UserScript==
// @name         ColorsOfGnoj
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       WinterThane
// @match        https://mn3njalnik.com/index.php?/forum/21-gnoji%C5%A1%C4%8De/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=simply-how.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var css = "#chatboxRoom { background: #929292; border-radius: 5px; } " +
        ".chatbox_msg { color: #111111; font-weight: bold; } " +
        "a { font-weight: bold; } " +
        ".cbTime { color: #000000; font-weight: bold } " +
        ".chatterName span { color: white; }"
    var style = document.createElement("style");
    style.type = "text/css";
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
    //data-member="WinterThane" -- target
    //class="chatterName" -- mn3 name
    //data-action="mention" -- text row with @ mention
    //class="ipsDataItem -- text row
    //
    //class="ipsFieldRow_content" -- text enter row
})();